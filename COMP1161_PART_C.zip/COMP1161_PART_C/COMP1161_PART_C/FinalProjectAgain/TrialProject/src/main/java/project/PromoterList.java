package project;
import java.awt.event.*;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.*;



public class PromoterList extends JPanel{
    
    private static JFrame frame;
    private JFrame   frame1;
    private JFrame   frame2;
    private JButton  sortName;
    private JButton  sortBudget;
    private JButton  promterData;
    private JButton closeButton;
    private JButton finishButton;
    private JButton saveButton;

    private JPanel   commandButtons;

    private ArrayList<Promoter> plist;
    private JScrollPane scrollPane;

    private JTable table;
    private DefaultTableModel model;

    public PromoterList(){
        super(new GridLayout(2,1));

        commandButtons= new JPanel();
        
        //Loads the promoters from the file into the table
        try
        {
            plist = loadPromoters(MainMenu.prom);
            String [] col={"ID","Name","Budget"};

            model = new DefaultTableModel(col,0);
            table = new JTable(model);

            showTable(plist);
        }
        catch(Exception ex)
        {
           
            System.out.println("Please select a file using MainMenu's file selector first");
        }

        table.setPreferredScrollableViewportSize(new Dimension(500, plist.size()*15 +50));
        table.setFillsViewportHeight(true);

        scrollPane= new JScrollPane(table);
        add(scrollPane);
        

        promterData = new JButton("Promoter Data");
        sortName= new JButton ("Sort Name");
        sortBudget= new JButton("Sort Budget");
        closeButton = new JButton("Close");
        saveButton = new JButton("Save to File");
    

        closeButton.addActionListener(new CloseMainButtonListener());       
        promterData.addActionListener(new PromoterButton());
        sortName.addActionListener(new SortNameButton());
        sortBudget.addActionListener(new SortBudgetButton());
        saveButton.addActionListener(new SaveTo());
    
        commandButtons.add(sortName);
        commandButtons.add(sortBudget);
        commandButtons.add(promterData);
        commandButtons.add(saveButton);
        commandButtons.add(closeButton);
       

        add(commandButtons);
    }

    /**
     * Action Listener for close button in Mainu menu
     */
    private class CloseMainButtonListener implements ActionListener {
        public void  actionPerformed(ActionEvent e) {
            frame.setVisible(false);
        }
    }

    //Listener for the Promoter Data Button
    private class PromoterButton implements ActionListener{
        private JButton addPromoter;
        private JButton editPromoter;
        private JButton deletePromoter;
        private JButton closeButton;
       
        private JPanel prompanel;
        public void actionPerformed(ActionEvent e){
            
            prompanel = new JPanel();
             //Create and set up the window
            frame1 = new JFrame("Promoter Action");
            frame1.setBounds(500,200,450,300);
            frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            addPromoter= new JButton("Add Promoter");
            editPromoter = new JButton("Edit Promoter");
            deletePromoter= new JButton("Delete Promoter");
            closeButton = new JButton("Close");

            prompanel.add(addPromoter);
            prompanel.add(editPromoter);
            prompanel.add(deletePromoter);
            prompanel.add(closeButton);

            closeButton.addActionListener(new CloseButtonListener());
            editPromoter.addActionListener(new EditPromoterButton());
            deletePromoter.addActionListener(new DeleteButton());
            addPromoter.addActionListener(new AddPromoterButton());

            frame1.add(prompanel);

            frame1.pack();
            frame1.setVisible(true);


        }

        //Listener for close button
        private class CloseButtonListener implements ActionListener {
            public void  actionPerformed(ActionEvent e) {
                frame1.setVisible(false);
            }
        }
    }

    //Listener for Sort Name
    private class SortNameButton implements ActionListener{
        public void actionPerformed(ActionEvent e){
            Collections.sort(plist, new SortName());
            model.setRowCount(0);
            showTable(plist);
        }
    }

    //Listener for Sort Budget
    private class SortBudgetButton implements ActionListener{
        public void actionPerformed(ActionEvent e){
            Collections.sort(plist,new SortBudget());
            model.setRowCount(0);
            showTable(plist);
        }
    }

    //Listener for Add Promoter
    private class AddPromoterButton implements ActionListener{
        private JTextField textname;
        private JTextField textbudget;
        private JPanel panel;
        private JPanel buttonPanel;
        private JButton continueButton;
        private JButton closeButton;
        private boolean checkBudget;

        public void actionPerformed(ActionEvent e){
            frame1.setVisible(false);
            panel= new JPanel();
            buttonPanel= new JPanel();
            //Create new Window
            frame2 = new JFrame("Add Promoter");
            frame2.setBounds(500,200,450,300);
            frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            panel.add(new JLabel("Enter Promoter Name "));
            textname= new JTextField(20);
            panel.add(textname);

            panel.add(new JLabel("Enter Promoter Budget "));
            textbudget= new JTextField(20);
            panel.add(textbudget);

            panel.setLayout(new GridLayout(3,4));

            continueButton = new JButton("Continue");
            closeButton = new JButton("Close");

            buttonPanel.add(continueButton);
            buttonPanel.add(closeButton);

            closeButton.addActionListener(new CloseButtonListener());
            continueButton.addActionListener(new AddContinueButton());

           
            frame2.add(panel, BorderLayout.CENTER );
            frame2.add(buttonPanel, BorderLayout.SOUTH);
            //Make window visible
            frame2.pack();
            frame2.setVisible(true);


        }

        //Listener for continue button
        private class AddContinueButton implements ActionListener{
            public void actionPerformed(ActionEvent e){
                frame2.setVisible(false);
                try{
                    Integer.parseInt(textbudget.getText());
                    checkBudget= true;
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(panel, "Budget must be a number");
                }

                if (checkBudget){
                    Ministry min = new Ministry(textname.getName(),1);
                    ArrayList<Venue> ven = new ArrayList<Venue>();
                    Promoter promoter = new Promoter(textname.getText(), Double.parseDouble(textbudget.getText()), min, ven);
                    plist.add(promoter);
                    addToTable(promoter);
                }
            }
        }
        //Listener for close button
        private class CloseButtonListener implements ActionListener {
            public void  actionPerformed(ActionEvent e) {
                frame2.setVisible(false);
            }
        }
    } 

    //Listener for Edit Promoter
    private class EditPromoterButton implements ActionListener{
        private JTextField textId;
        private JPanel panel;
        private JPanel buttonPanel;
        private JButton continueButton;
        private JButton closeButton;
        private JRadioButton nameButton;
        private JRadioButton budgetButton;
        private JRadioButton bothButton;
        private int buttonNumber; //Track which button was selected

        public void actionPerformed(ActionEvent e){
            frame1.setVisible(false);
            panel= new JPanel();
            buttonPanel= new JPanel();
            //Create new Window
            frame2 = new JFrame("Edit Promoter");
            frame2.setBounds(500,200,450,300);
            frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            panel.add(new JLabel("Enter ID of promoter to be edited "));
            textId= new JTextField(3);
            panel.add(textId);

            continueButton = new JButton("Continue");
            closeButton = new JButton("Close");
            buttonPanel.add(continueButton);
            buttonPanel.add(closeButton);

            closeButton.addActionListener(new CloseButtonListener());
            continueButton.addActionListener(new EditContinueButton());

            frame2.add(panel, BorderLayout.CENTER );
            frame2.add(buttonPanel, BorderLayout.SOUTH);
            //Make window visible
            frame2.pack();
            frame2.setVisible(true);

        }

        //Listener for close button
        private class CloseButtonListener implements ActionListener {
            public void  actionPerformed(ActionEvent e) {
                frame2.setVisible(false);
            }
        }

        //Listener for continue button
        private class EditContinueButton implements ActionListener{
            private JPanel panel;

            public void actionPerformed(ActionEvent e){
                frame2.setVisible(false);
                if (findPromoter(plist, Integer.parseInt(textId.getText()))>=0){
                    panel= new JPanel();
                    frame1 = new JFrame("Edit Promoter");
                    frame1.setBounds(500,200,450,300);
                    frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    nameButton = new JRadioButton("Name Only");
                    budgetButton = new JRadioButton("Budget Only");
                    bothButton = new JRadioButton("Both");

                    ButtonGroup group = new ButtonGroup();
                    group.add(nameButton);
                    group.add(budgetButton);
                    group.add(bothButton);

                    frame1.add(new JLabel("Do you want to edit name or budget?"),BorderLayout.NORTH);
                    panel.add(nameButton);
                    panel.add(budgetButton);
                    panel.add(bothButton);

                    nameButton.addActionListener(new RadioButtons());
                    budgetButton.addActionListener(new RadioButtons());
                    bothButton.addActionListener(new RadioButtons());


                    panel.setLayout(new GridLayout(5,5));

                    frame1.add(panel, BorderLayout.CENTER );
                   //Make window visible
                    frame1.pack();
                    frame1.setVisible(true);
                }else {
                    panel= new JPanel();
                    JPanel buttonPanel=new JPanel();
                    frame1 = new JFrame("Edit Promoter");
                    frame1.setBounds(500,200,450,300);
                    frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    panel.add(new JLabel("Promoter not found"));
                    finishButton= new JButton("Finish");

                    finishButton.addActionListener(new FinishButton());
            
                    buttonPanel.add(finishButton);

                    frame1.add(panel, BorderLayout.CENTER);
                    frame1.add(buttonPanel, BorderLayout.SOUTH);
                    //Make window visible
                    frame1.pack();
                    frame1.setVisible(true);
                }    
                    
            }
        }

        //Listener for RadioButtons
        private class RadioButtons implements ActionListener{
            private JPanel panel;
            private JPanel buttonPanel;
            private JButton saveButton;
            private JButton closeButton;
            private JTextField textname;
            private JTextField textbudget;
            
  
            public void actionPerformed(ActionEvent e){
                frame1.setVisible(false);
                    int pdx=findPromoter(plist, Integer.parseInt(textId.getText()));
                    if (e.getSource()==nameButton){
                        buttonNumber=1;

                        panel=new JPanel();
                        buttonPanel = new JPanel();
                        frame2 = new JFrame("Edit Promoter Information");
                        frame2.setBounds(500,200,450,300);
                        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        panel.add(new JLabel("Current name is "+ plist.get(pdx).getName()));

                        panel.add(new JLabel("Enter new name"));
                        textname=new JTextField(20);
                        panel.add(textname);

                        saveButton = new JButton("Save");
                        closeButton = new JButton("Close");
                        buttonPanel.add(saveButton);
                        buttonPanel.add(closeButton);

                        closeButton.addActionListener(new CloseButtonListener());
                        saveButton.addActionListener(new EditSaveButton());

                        frame2.add(panel, BorderLayout.CENTER );
                        frame2.add(buttonPanel, BorderLayout.SOUTH);

                        frame2.pack();
                        frame2.setVisible(true);

                    }else  if (e.getSource()==budgetButton){
                        buttonNumber=2;
                        panel=new JPanel();
                        buttonPanel = new JPanel();
                        frame2 = new JFrame("Edit Promoter Information");
                        frame2.setBounds(500,200,450,300);
                        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        panel.add(new JLabel("Enter new budget"));
                        textbudget=new JTextField(20);
                        panel.add(textbudget);

                        saveButton = new JButton("Save");
                        closeButton = new JButton("Close");
                        buttonPanel.add(saveButton);
                        buttonPanel.add(closeButton);

                        closeButton.addActionListener(new CloseButtonListener());
                        saveButton.addActionListener(new EditSaveButton());

                        frame2.add(panel, BorderLayout.CENTER );
                        frame2.add(buttonPanel, BorderLayout.SOUTH);

                        frame2.pack();
                        frame2.setVisible(true);
                    }else if (e.getSource()==bothButton){
                        buttonNumber=3;
                        panel=new JPanel();
                        buttonPanel = new JPanel();
                        frame2 = new JFrame("Edit Promoter Information");
                        frame2.setBounds(500,200,450,300);
                        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        panel.add(new JLabel("Enter new name"));
                        textname=new JTextField(20);
                        panel.add(textname);

                        panel.add(new JLabel("Enter new budget"));
                        textbudget=new JTextField(20);
                        panel.add(textbudget);

                        saveButton = new JButton("Save");
                        closeButton = new JButton("Close");
                        buttonPanel.add(saveButton);
                        buttonPanel.add(closeButton);

                        closeButton.addActionListener(new CloseButtonListener());
                        saveButton.addActionListener(new EditSaveButton());

                        frame2.add(panel, BorderLayout.CENTER );
                        frame2.add(buttonPanel, BorderLayout.SOUTH);

                        frame2.pack();
                        frame2.setVisible(true);
                    }
            }

            //Listener for save button
            private class EditSaveButton implements ActionListener{
                int pdx;
                public void actionPerformed(ActionEvent e){
                        try{
                            frame2.setVisible(false);
                            pdx= findPromoter(plist, Integer.parseInt(textId.getText()));
                            if (buttonNumber==1){
                                plist.get(pdx).setName(textname.getText());
                                panel=new JPanel();
                                buttonPanel= new JPanel();
                                frame1 = new JFrame("Success!!");
                                frame1.setBounds(500,200,450,300);
                                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


                                panel.add(new JLabel("Promoter with ID# "+ Integer.parseInt(textId.getText())+" has been edited"));
                                finishButton= new JButton("Finish");
                                buttonPanel.add(finishButton);

                                finishButton.addActionListener(new FinishButton());

                                //Make window visible
                                frame1.add(panel, BorderLayout.CENTER);
                                frame1.add(buttonPanel, BorderLayout.SOUTH);
                                frame1.pack();
                                frame1.setVisible(true);
                                model.setRowCount(0);
                                showTable(plist);
                                
                            }
                            else if (buttonNumber==2){
                                plist.get(pdx).setBudget(Integer.parseInt(textbudget.getText()));
                                panel=new JPanel();
                                buttonPanel= new JPanel();
                                frame1 = new JFrame("Success!!");
                                frame1.setBounds(500,200,450,300);
                                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                                panel.add(new JLabel("Promoter with ID# "+ Integer.parseInt(textId.getText())+" has been edited"));
                                finishButton= new JButton("Finish");
                                buttonPanel.add(finishButton);

                                finishButton.addActionListener(new FinishButton());

                                frame1.add(panel, BorderLayout.CENTER);
                                frame1.add(buttonPanel,BorderLayout.SOUTH);
                                //Make window visible
                                frame1.pack();
                                frame1.setVisible(true);
                                model.setRowCount(0);
                                showTable(plist);

                            }else if (buttonNumber==3 ){
                                plist.get(pdx).setName(textname.getText());
                                plist.get(pdx).setBudget(Integer.parseInt(textbudget.getText()));
                                panel=new JPanel();
                                buttonPanel=new JPanel();
                    
                                frame1 = new JFrame("Success!!");
                                frame1.setBounds(500,200,450,300);
                                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                                panel.add(new JLabel("Promoter with ID# "+ Integer.parseInt(textId.getText())+" has been edited"));
                                finishButton= new JButton("Finish");
                                buttonPanel.add(finishButton);

                                finishButton.addActionListener(new FinishButton());

                                frame1.add(panel, BorderLayout.CENTER);
                                frame1.add(buttonPanel, BorderLayout.SOUTH);
                                //Make window visible
                                frame1.pack(); 
                                frame1.setVisible(true);
                                model.setRowCount(0);
                                showTable(plist);
                            }
                            
                        }catch (NumberFormatException ex){
                            JOptionPane.showMessageDialog(panel, "Budget must be a number");

                        }
                    
                }
 
            }
        }

    }

    //Listener for Finish button
    private class   FinishButton extends JFrame implements ActionListener{
        public void actionPerformed(ActionEvent ez){
            frame1.setVisible(false);
        }
    }
    //Listener for delete button
    private class DeleteButton implements ActionListener{
        private JPanel panel;
        private JPanel buttonJPanel;
        private JButton continueButton;
        private JButton closeButton;
        private JTextField textid;

        public void actionPerformed(ActionEvent e){
            frame1.setVisible(false);
            panel = new JPanel();
            buttonJPanel= new JPanel();

            frame2 = new JFrame("Delete Promoter");
            frame2.setBounds(500,200,450,300);
            frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            panel.add(new JLabel("Enter promoter ID to be deleted"));
            textid = new JTextField(3);
            panel.add(textid);

            continueButton= new JButton("Continue");
            closeButton = new JButton("Close");

            buttonJPanel.add(continueButton);
            buttonJPanel.add(closeButton);

            closeButton.addActionListener(new CloseButtonListener());
            continueButton.addActionListener(new DeleteContinueButton());

            frame2.add(panel, BorderLayout.CENTER);
            frame2.add(buttonJPanel, BorderLayout.SOUTH);
            //Make window visible
            frame2.pack();
            frame2.setVisible(true);


        }
        //Listener for close button
        private class CloseButtonListener implements ActionListener {
            public void  actionPerformed(ActionEvent e) {
                frame2.setVisible(false);
            }
        }

        //Listener for Continue Button
        private class DeleteContinueButton implements ActionListener{
            private int pdx;
            public void actionPerformed(ActionEvent e){
            frame2.setVisible(false);

                try{
                    panel= new JPanel();
                    JPanel buttonPanel=new JPanel();
                    if (findPromoter(plist, Integer.parseInt(textid.getText()))>=0){
                        pdx=findPromoter(plist, Integer.parseInt(textid.getText()));
                        plist.remove(pdx);
                        
                        frame1 = new JFrame("Success!!");
                        frame1.setBounds(500,200,450,300);

                        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        panel.add(new JLabel("Promoter with ID# "+ Integer.parseInt(textid.getText())+" deleted"));
                        finishButton= new JButton("Finish");

                        finishButton.addActionListener(new FinishButton());
            
                        buttonPanel.add(finishButton);


                        frame1.add(panel, BorderLayout.CENTER);
                        frame1.add(buttonPanel, BorderLayout.SOUTH);
                        //Make window visible
                        frame1.pack();
                        frame1.setVisible(true);
                        model.setRowCount(0);
                        showTable(plist);
                    }else{
                        frame1 = new JFrame("Edit Promoter");
                        frame1.setBounds(500,200,450,300);

                        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        panel.add(new JLabel("Promoter not found"));
                        finishButton= new JButton("Finish");

                        finishButton.addActionListener(new FinishButton());
            
                        buttonPanel.add(finishButton);

                        frame1.add(panel, BorderLayout.CENTER);
                        frame1.add(buttonPanel, BorderLayout.SOUTH);

                        //Make window visible
                        frame1.pack();
                        frame1.setVisible(true);

                    }  
                }catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(panel, "ID must be a number");
                }
            }
        }
    }

    //Class to sort name
    class SortName implements Comparator<Promoter>{
        public int compare(Promoter p1, Promoter p2){
            return p1.getName().compareTo(p2.getName());
        }
    }

    //class to Sort budget 
    class SortBudget implements Comparator<Promoter>{
        public int compare(Promoter p1, Promoter p2){
            if (p1.getBudget()>p2.getBudget())
                return 1;
            else if (p1.getBudget()<p2.getBudget())
                return -1;
            else     
                return 0;
        }
    }

    //Listener to Save button in the main menu
    private class SaveTo implements ActionListener{   
        public void actionPerformed(ActionEvent e){
           try {
                savePromoter(MainMenu.prom);   
            } 
            catch (IOException e1) {e1.printStackTrace();}
        }
    }

   //************************************************************************************************************ */

   
   
   public static void createAndShowGUI() 
    {
        //Create and set up the window.
        frame = new JFrame("List of Promoters");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(500,200,450,300);

        //Create and set up the content pane.
        PromoterList newContentPane = new PromoterList();
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    /**
     * Takes promoters out the list and adds them to the table
     * @param plist Arraylist of promoters
     */
    private void showTable(ArrayList<Promoter> plist){
        if (plist.size()>0){
            for (int promo=0; promo<plist.size(); promo++)
            {
                addToTable(plist.get(promo));
            }
        }
    }

    /**
     * Takes the Id, name and budget of the promoter and adds it to a row in the table
     * @param p Promoter
     */
    private void addToTable(Promoter p){
        String[] item={""+p.getId(),p.getName(),""+p.getBudget()};
        model.addRow(item);        
        }




    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
            });
        }

    /**
     * Reads information from a file and creates a promoter with the information and adds it 
     * to an arraylist of promoters
     * @param pfile File name
     * @return Arraylist of promoters
     */
    private ArrayList<Promoter> loadPromoters(String pfile){
        Scanner pscan = null;
        ArrayList<Promoter> prom =  new ArrayList<Promoter>();
        try{
            pscan = new Scanner(new File(pfile));
            while(pscan.hasNext()){
                String [] promo=pscan.nextLine().split(" ");
                String name = promo[0];
                double budget= Double.parseDouble(promo[1]);
                Ministry min = new Ministry(name,1);
                ArrayList<Venue> ven = new ArrayList<Venue>();
                Promoter p=new Promoter(name,budget,min,ven);
                prom.add(p);
            }
            pscan.close();
           
        }
        catch (IOException e){}
          return prom; 
        }
    
    /**
     * Given an ID, this method searches a arraylist of promoters and return the index number of 
     * the promoter that matches the ID else -1 is returned
     * @param proms Arraylist of promoters
     * @param pid Id of promoter to be found
     * @return index of promoter
     */
    public int findPromoter(ArrayList<Promoter> proms, int pid){
        int pdx =-1;
        int currdx=0;
        while ((currdx<proms.size())&&(pdx==-1)){
            if (proms.get(currdx).getId()==pid)
                pdx = currdx;
            currdx++;

        }

        return pdx;

    }


    
    
     public void savePromoter(String promoter) throws IOException
    {
       FileWriter file = new FileWriter (promoter,false);
       BufferedWriter b =  new BufferedWriter (file);
       for (Promoter p:plist)
       {
        b.write(p.getName()+" "+p.getBudget());
        b.newLine();
       }
       b.close();
       file.close();
    }



}