package project;

import java.util.Scanner;

public class PartyVenue extends Venue{
	double stageArea;
	double barArea, foodArea;
	int numSecurity;
	
	/**
	 * This constructs a Party Venue with a specified name, stage area,
	 * bar area, food area, number of security, base price and level 
	 * @param name Name of venue
	 * @param stageArea stage area of the venue
	 * @param barArea bar area of venue
	 * @param foodArea Food area of venue
	 * @param numSecurity Number os security
	 * @param basePrice Base price of the venue
	 * @param lev The alert level
	 */

	public PartyVenue(String name, double stageArea,	double barArea, 
			           double foodArea,int numSecurity, double basePrice,
			            int lev)
	{
		super( name, stageArea+barArea+foodArea, basePrice, lev);
		this.numSecurity=numSecurity;
		this.stageArea = 	stageArea;
		this.barArea = barArea;
		this.foodArea = foodArea;
                this.type = 7;
		
		
		
	}
	
	public double getEstimate(String type)
	{
		double price = basePrice;
		if (type.equals("PARTY"))
			price += partyPrep;
		if (type.equals("SPORT"))
			price += sportsPrep;
		if (type.equals("TRAINING"))
			price += trainPrep;
	
		
		//System.out.println(this.getName()+":estimate  to hold a "+type +" is "+ price);
		return price;

	}
	
	public double getCurrStage()
	{
		return stageArea;
	}
	
	public double getBarArea()
	{
		return barArea;
	}
	
	public double getFoodArea()
	{
		return foodArea;
	}
	
	
	public int getNumSecurity()
	{
		return numSecurity;
	}
	
	public void setStageArea(double stageArea)
	{
		
		this.stageArea =stageArea;
	}
	
	public void setFoodArea(double foodArea)
	{
		
		this.foodArea =foodArea;
	}
	
	public void setBarArea(double barArea)
	{
		
		this.barArea =barArea;
	}	
	
	public void setNumSecurity(int numSecurity)
	{
		
		this.numSecurity =numSecurity;
	}

	
	   public String toString()
	   {
	   	return "ID:"+this.getId()+";"+this.getName() +";#Events:"+this.getApprovedEvents().size()+";Stage Area:"+stageArea+";Bar Area:"+barArea+";Food Area:"+foodArea+";#Sec"+numSecurity;
	   	
	   }
	   public String toFile()
	   {
		   	return ""+this.getId()+";"+this.getName() +";"+this.getApprovedEvents().size()+";"+stageArea+";"+barArea+";"+foodArea+";"+numSecurity;
		   	
		   }	
	
	/**
	 * Updates a Party venue by allowing the user edit the name, stage area, bar area, food area, number of security, base price and level of the venue
	 * @override Override the UpdateLocalData method in the venue class
	 * @param scan A file
	 */
	public void updateLocalData(Scanner scan){	
		scan.nextLine();
		String currname = getName();
		double currbarArea = getBarArea();
		double currstageArea = getCurrStage();
		double currPrice= getPrice();
		double currfoodarea = getFoodArea();
		int currSecurity= getNumSecurity();
		int currlevel= getLevel();
		
		System.out.println("Hit enter to keep name as ["+currname+"], or enter new name:");
		String name = scan.nextLine();
		if (name.equals(""))
			name = currname;
		
		System.out.println("Hit enter to keep Stage Area at ["+currstageArea +"] or enter new Satge Area:");
		String SArea=scan.nextLine();
		double staArea;
		if (SArea.equals(""))
			staArea = currstageArea;
		else
			staArea = Double.parseDouble(SArea);

		System.out.println("Hit enter to keep Bar Area at ["+currbarArea +"] or enter new Bar Area:");
		String BArea=scan.nextLine();
		double barrarea;
		if (BArea.equals(""))
			barrarea = currbarArea;
		else
			barrarea = Double.parseDouble(BArea);

		System.out.println("Hit enter to keep Food Area at ["+currfoodarea +"] or enter new Food Area:");
		String FArea=scan.nextLine();
		double fooarea;
		if (FArea.equals(""))
			fooarea = currfoodarea;
		else
			fooarea = Double.parseDouble(FArea);

		System.out.println("Hit enter to keep Security Number at ["+currSecurity +"] or enter new Security Number:");
		String security=scan.nextLine();
		int securityNum;
		if (security.equals(""))
			securityNum = currSecurity;
		else
			securityNum = Integer.parseInt(security);

		

		System.out.println("Hit enter to keep base price at ["+currPrice +"] or enter new base price:");
		String Vprice=scan.nextLine();
		double basePrice;
		if (Vprice.equals(""))
			basePrice = currPrice;
		else
			basePrice = Double.parseDouble(Vprice);

		System.out.println("Hit enter to keep level at ["+currlevel +"] or enter new level:");
		String Vlevel=scan.nextLine();
		int level;
		if (Vlevel.equals(""))
			level = currlevel;
		else
			level = Integer.parseInt(Vlevel);

		super.setName(name);
		super.setPrice(basePrice);
		super.setLevel(level);
		setBarArea(barrarea);
		setStageArea(staArea);
		setFoodArea(fooarea);
		setNumSecurity(securityNum);

	}
        public void updateLocalData(String entered)
        {   
            String[] data = entered.split("/");
            String currName;
            double currArea1;
            double currArea2;
            double currArea3;
            int numSecurity;
            double currPrice; 
            int currLevel;
            
            
            if(data[0].equals("&"))
                    currName= getName();
                else
                    currName = data[0];
                if(data[1].equals("&"))
                    currArea1 = getCurrStage();
                else
                    currArea1 = Double.parseDouble(data[1]);
                if(data[2].equals("&"))  
                    currArea2 = getBarArea();
                else
                    currArea2 = Double.parseDouble(data[2]);
                if(data[3].equals("&"))
                    currArea3 = getFoodArea();
                else
                    currArea3 = Double.parseDouble(data[3]);
                
                if(data[4].equals("&"))
                    numSecurity = getNumSecurity();
                else
                    numSecurity = Integer.parseInt(data[4]);
                    
                if(data[5].equals("&"))
                    currPrice = getPrice();
                else
                    currPrice = Double.parseDouble(data[5]);
                if(data[6].equals("&"))
                    currLevel = getLevel();
                else
                    currLevel = Integer.parseInt(data[6]);
                
            setName(currName);
            setStageArea(currArea1);
            setFoodArea(currArea2);
            setBarArea(currArea3);
            setNumSecurity(numSecurity);
            setPrice(currPrice);
            setLevel(currLevel);
        }
}
