package project;

import java.util.Scanner;

public class TrainingVenue extends Venue {
	private double instructorArea;
	private double otherArea;
        
   	

	/**
	 * This constructs a Training Venue with a specified name, instruction area,
	 * other area, base price and level 
	 * @param name Name of venue
	 * @param instructorArea Instructor area of the venue
	 * @param otherArea Other area of venue
	 * @param basePrice Base price of the venue
	 * @param lev The alert level
	 */
	public TrainingVenue(String name, double instructorArea, double otherArea,
			double basePrice,int lev)
	{
	super(name, instructorArea +otherArea, basePrice,  lev);
	this.instructorArea = 	instructorArea;
	this.otherArea = otherArea;
        type = 5;

	}
	public double getEstimate(String type)
	{
			double price = basePrice;
			if (type.equals("PARTY"))
				price += partyPrep;
			if (type.equals("SPORT"))
					price += sportsPrep;

			//System.out.println(this.getName()+":estimate  to hold a "+type +" is "+ price);
			return price;

		}



	public double getInstructorArea()
	{
		return instructorArea;
	}

	public double getOtherArea()
	{
		return otherArea;
				
	}



	public void setInstructorArea(double instructorArea)
	{
		
		this.instructorArea =instructorArea;
	}

	public void setOtherArea(double otherArea)
	{
		
		this.otherArea =otherArea;
	}

	public String toString()
	{
		return "ID:"+this.getId()+";"+this.getName() +";#Events:"+this.getApprovedEvents().size()+";Inst.Area"+instructorArea+";Oth.Area"+otherArea;
		
	}
	public String toFile()
	{
		return ""+this.getId()+";"+this.getName() +";"+this.getApprovedEvents().size()+";"+instructorArea+";"+otherArea;
		
	}
	
	/**
	 * Updates a Trainig venue by allowing the user edit the name, instructor area, other area, price and level of the venue
	 * @override Override the UpdateLocalData method in the venue class
	 * @param scan A file
	 */
	public void updateLocalData(Scanner scan){	
		scan.nextLine();
		String currname = getName();
		double currInstrucArea = getInstructorArea();
		double currOtherArea = getOtherArea();
		double currPrice= getPrice();
		int currlevel= getLevel();
		System.out.println("Hit enter to keep name as ["+currname+"], or enter new name:");
		String name = scan.nextLine();
		if (name.equals(""))
			name = currname;

		System.out.println("Hit enter to keep Instructor Area at ["+currInstrucArea +"] or enter new Instructor Area:");
		String IArea=scan.nextLine();
		double instructArea;
		if (IArea.equals(""))
			instructArea = currInstrucArea;
		else
			instructArea = Double.parseDouble(IArea);

		System.out.println("Hit enter to keep Other Area at ["+currOtherArea +"] or enter new Other Area:");
		String OArea=scan.nextLine();
		double othArea;
		if (OArea.equals(""))
			othArea = currInstrucArea;
		else
			othArea = Double.parseDouble(OArea);

		System.out.println("Hit enter to keep base price at ["+currPrice +"] or enter new base price:");
		String Vprice=scan.nextLine();
		double basePrice;
		if (Vprice.equals(""))
			basePrice = currPrice;
		else
			basePrice = Double.parseDouble(Vprice);

		System.out.println("Hit enter to keep level at ["+currlevel +"] or enter new level:");
		String Vlevel=scan.nextLine();
		int level;
		if (Vlevel.equals(""))
			level = currlevel;
		else
			level = Integer.parseInt(Vlevel);

		super.setName(name);
		setInstructorArea(instructArea);
		super.setPrice(basePrice);
		super.setLevel(level);
		setOtherArea(othArea);

	}
        public void updateLocalData(String entered)
        {   
            String[] data = entered.split("/");
            String currName;
            double currArea1;
            double currArea2;
            double currArea3;
            int numSecurity;
            double currPrice; 
            int currLevel;
            
            
            if(data[0].equals("&"))
                    currName= getName();
                else
                    currName = data[0];
                if(data[1].equals("&"))
                    currArea1 = getInstructorArea();
                else
                    currArea1 = Double.parseDouble(data[1]);
                if(data[2].equals("&"))  
                    currArea2 = getOtherArea();
                else
                    currArea2 = Double.parseDouble(data[2]);
                if(data[3].equals("&"))
                    currArea3 = 0;
                else
                    currArea3 = Double.parseDouble(data[3]);
                
                if(data[4].equals("&"))
                    numSecurity = getNumSecurity();
                else
                    numSecurity = Integer.parseInt(data[4]);
                    
                if(data[5].equals("&"))
                    currPrice = getPrice();
                else
                    currPrice = Double.parseDouble(data[5]);
                if(data[6].equals("&"))
                    currLevel = getLevel();
                else
                    currLevel = Integer.parseInt(data[6]);
                
            setName(currName);
            setInstructorArea(currArea1);
            setOtherArea(currArea2);
            //setBarArea(area3);
            //setNumSecurity(numSecurity);
            setPrice(currPrice);
            setLevel(currLevel);
        }

}

