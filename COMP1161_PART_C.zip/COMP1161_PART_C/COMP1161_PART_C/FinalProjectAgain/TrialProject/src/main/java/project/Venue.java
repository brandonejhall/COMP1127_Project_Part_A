package project;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *Venue
 **/

public class Venue implements Comparable<Venue> {
	private String name;
	private double size;
        protected int type=4;
	protected double basePrice;
	private ArrayList<Event> approvedEvents=new ArrayList<Event>();
	private int level; // 1,2,3 for low,medium, high repectively;
	private int id;
	private static int nextId=0;
	protected double partyPrep=2000,  trainPrep=500, sportsPrep = 1000;
	
	
	public Venue() 
	{}
	/**
	 * This constructs a Venue with a specified name, size, baseprice and level
	 * @param name The name of the venue
	 * @param size The size of the venue
	 * @param basePrice The base price of the venue
	 * @param lev The alert level
	 */
	public Venue( String name, double size, double basePrice, int lev)
	{
        this.name = name;
		this.size = size;
		this.basePrice=basePrice;
		this.level = lev;
	
		id =nextId;
		nextId++;
		

	}
	
	public static void resetId()
	{
		
		nextId=0;
	}
	
	//////
	
	public int compareTo(Venue other)
	{
		return this.getName().compareTo(other.getName());
	}
	
	public double getSize()
	{
		return size;
	
	}
	
	public String getName()
	{
		return name;
	}
	public double getPrice()
	{
		return basePrice;
	
	}
	
	public int getLevel()
	{
		return level;
	}
        
        public int getNumSecurity(){return 2;}
        
        public double getCurrStage()
	{
		return 2.0;
	}
	
	public double getBarArea()
	{
		return 2.0;
	}
	
	public double getFoodArea()
	{
		return 2.0;
	}
        
        public int getType(){return type;}
	
	/**
	 * Updates a General venue by allowing the user edit the name, size, price and level of the venue
	 * @param scan A file
	 */
	public void updateLocalData(Scanner scan){	
		scan.nextLine();
		String currname = getName();
		double currSize = getSize();
		double currPrice= getPrice();
		int currlevel= getLevel();
		System.out.println("Hit enter to keep name as ["+currname+"], or enter new name:");
		String name = scan.nextLine();
		if (name.equals(""))
			name = currname;

		System.out.println("Hit enter to keep size at ["+currSize +"] or enter new size:");
		String Vsize=scan.nextLine();
		double size;
		if (Vsize.equals(""))
			size = currSize;
		else
			size = Double.parseDouble(Vsize);

		System.out.println("Hit enter to keep base price at ["+currPrice +"] or enter new base price:");
		String Vprice=scan.nextLine();
		double basePrice;
		if (Vprice.equals(""))
			basePrice = currPrice;
		else
			basePrice = Double.parseDouble(Vprice);

		System.out.println("Hit enter to keep level at ["+currlevel +"] or enter new level:");
		String Vlevel=scan.nextLine();
		int level;
		if (Vlevel.equals(""))
			level = currlevel;
		else
			level = Integer.parseInt(Vlevel);

		setName(name);
		setSize(size);
		setPrice(basePrice);
		setLevel(level);

	}
        public void updateLocalData(String entered)
        {   
            String[] data = entered.split("/");
            String currName;
            double currArea1;
            double currArea2;
            double currArea3;
            int numSecurity;
            double currPrice; 
            int currLevel;
            
            
            if(data[0].equals("&"))
                    currName= getName();
                else
                    currName = data[0];
                if(data[1].equals("&"))
                    currArea1 = getSize();
                else
                    currArea1 = Double.parseDouble(data[1]);
                if(data[2].equals("&"))  
                    currArea2 = 0;
                else
                    currArea2 = Double.parseDouble(data[2]);
                if(data[3].equals("&"))
                    currArea3 = 0;
                else
                    currArea3 = Double.parseDouble(data[3]);
                
                if(data[4].equals("&"))
                    numSecurity = getNumSecurity();
                else
                    numSecurity = Integer.parseInt(data[4]);
                    
                if(data[5].equals("&"))
                    currPrice = getPrice();
                else
                    currPrice = Double.parseDouble(data[5]);
                if(data[6].equals("&"))
                    currLevel = getLevel();
                else
                    currLevel = Integer.parseInt(data[6]);
                
            setName(currName);
            setSize(currArea1);
            //setOtherArea(currArea2);
            //setBarArea(area3);
            //setNumSecurity(numSecurity);
            setPrice(currPrice);
            setLevel(currLevel);
        }
	
	public void setName(String name)
	{
		
		this.name =name;
	}
	
	public void setPrice(double basePrice)
	{
		
		this.basePrice =basePrice;
	}
	
	public void setSize(double size)
	{
		
		this.size =size;
	}	
	
	public void setLevel(int level)
	{
		
		this.level =level;
	}
	
	
	public double getEstimate(String type)
	{
		double price = basePrice;
		if (type.equals("PARTY"))
			price += partyPrep;
		if (type.equals("SPORT"))
			price += sportsPrep;
		if (type.equals("TRAINING"))
			price += trainPrep;
	
		
		//System.out.println(this.getName()+":estimate  to hold a "+type +" is "+ price);
		return price;

	}

public int getId()
{
	return id;
}


	public int reserve( Event event,double availBal, Ministry min)

	{   
		System.out.println("Submitted "+event +" for approval at " + this);
		ApprovalRequest ar = new ApprovalRequest(event, this);
	int approval = min.checkApproval(ar);
	if (approval>=0)
	{
		if (availBal >= getEstimate(event.getType()))
		{
            approvedEvents.add(event);
			event.setVenue(this);
			System.out.println("Successfully Approved and registered "+event.toString());
		}
			
	}
			
	return approval;
	}
	
	public boolean available(Date date)
	{
		boolean returnVal=true;
			
		ArrayList<Integer> reservedDays = new ArrayList<Integer>();
		for(Event e:approvedEvents)
			reservedDays.add(e.getDate().getDay());
		int dx =0;
		while ((dx<reservedDays.size())&&(returnVal))
		{
			if (date.getDay()==approvedEvents.get(dx).getDate().getDay())
				returnVal=false;
			dx++;
		}
		//System.out.println("checking  "+getName()+" availability for "+ date.getDay()+":"+ returnVal);
		
		
		return returnVal;
	}
	
	public  boolean canHold(int nump)
	{
		boolean returnVal = false;
		
	    int separation=0;
	  		switch(level)
	   		{
	   		case 1:{
	   			separation= Ministry.LOWRISK_SEPARATION;
	   			break;
	   		}
	   		case 2:{
	   			separation= Ministry.MEDIUMRISK_SEPARATION;
	   			break;
	   		}
	   		case 3:{
	   			separation= Ministry.HIGHRISK_SEPARATION;
	   			break;
	   		}
	   		}
	  	//System.out.println(this.getName()+":"+this.getSize()+"/"+separation);
        if (nump <(int)(getSize()/separation))
           returnVal = true;
        
        else
        	 returnVal= false;
		//System.out.println("checking  "+getName()+" space for "+ nump +" persons "+":"+ returnVal);

		return returnVal;
	}


	public void promoteEvents(PrintStream outStream)
	{
		outStream.println("EVENTS AT "+getName());
		outStream.println("===================");
	    for(Event e:approvedEvents)
		   outStream.println(e);
	    outStream.println("--------------------");
		   
	}
	
	public ArrayList<Event> getApprovedEvents()
	{
		
		return approvedEvents;
	}
	

	public String toString()
	{
		return "ID:"+this.getId()+";"+this.name +";#Events:"+this.approvedEvents.size()+";Area:"+this.getSize();
		
	}
	
	public String toFile()
	{
		return ""+this.getId()+";"+this.name +";"+this.approvedEvents.size()+";"+this.getSize();
		
	}

    

    

}
