package project;

/*package project;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
//import project.Tester;
public class Driver {
    WorkArea workArea = new WorkArea();

    
	public static void main(String[] args) {
		PromoterList list = new PromoterList();
}

}*/