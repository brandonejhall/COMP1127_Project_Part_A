package project;

import java.util.Scanner;

public class SportsVenue extends  Venue {
   private double competitorArea;
   private double spectatorArea;
   private int numSecurity;
   
	/**
	 * This constructs a Sport Venue with a specified name, competitor area,
	 * spectator area, number of security, base price and level 
	 * @param name Name of venue
	 * @param competitorArea Competitor area of the venue
	 * @param spectatorArea Spectator area of venue
	 * @param numSecurity Number os security
	 * @param basePrice Base price of the venue
	 * @param lev The alert level
	 */
   public SportsVenue(String name, double competitorArea, double spectatorArea,
		              int numSecurity, double basePrice, int lev)
	{
	super(name, competitorArea +spectatorArea, basePrice,  lev);
	this.competitorArea = 	competitorArea;
	this.spectatorArea = spectatorArea;
	this.numSecurity=numSecurity;
        this.type = 6;
	}
   
   public double getSize()
   {
	   return competitorArea+ spectatorArea;
   }
   
   public int countSecurity()
   {
	   return numSecurity;
   }
   
   

	public double getCompArea()
	{
		return competitorArea;
	}
	
	public double getSpecArea()
	{
		return spectatorArea;
				
	}
	

	
	public int getNumSecurity()
	{
		return numSecurity;
	}
	
	
	public void setCompArea(double competitorArea)
	{
		
		this.competitorArea =competitorArea;
	}
	
	public void setSpecArea(double spectatorArea)
	{
		
		this.spectatorArea =spectatorArea;
	}
	

	
	public void setNumSecurity(int numSecurity)
	{
		
		this.numSecurity =numSecurity;
	}

	
	public double getEstimate(String type)
	{
		double price = basePrice;
		if (type.equals("PARTY"))
			price += partyPrep;
		if (type.equals("TRAINING"))
			price += trainPrep;
	
		
		//System.out.println(this.getName()+":estimate  to hold a "+type +" is "+ price);
		return price;

	}
	   public String toString()
	   {
	   	return "ID:"+this.getId()+";"+this.getName() +";#Events:"+this.getApprovedEvents().size()+";Compet Area:"+competitorArea+";Spec Area:"+spectatorArea+";#Sec:"+numSecurity;
	   	
	   }
	   public String toFile()
	   {
		   	return ""+this.getId()+";"+this.getName() +";"+this.getApprovedEvents().size()+";"+competitorArea+";"+spectatorArea+";"+numSecurity;
		   	
		}

	/**
	 * Updates a Sport venue by allowing the user edit the name, competitor area, spectator area, number of security, base price and level of the venue
	 * @override Override the UpdateLocalData method in the venue class
	 * @param scan A file
	 */

	public void updateLocalData(Scanner scan){	
		scan.nextLine();
		String currname = getName();
		double currCompArea = getCompArea();
		double currSpecArea = getSpecArea();
		double currPrice= getPrice();
		int currlevel= getLevel();
		int currSecurity= getNumSecurity();
		System.out.println("Hit enter to keep name as ["+currname+"], or enter new name:");
		String name = scan.nextLine();
		if (name.equals(""))
			name = currname;

		System.out.println("Hit enter to keep Competitor Area at ["+currCompArea +"] or enter new Competitor Area:");
		String CArea=scan.nextLine();
		double comArea;
		if (CArea.equals(""))
			comArea = currCompArea;
		else
			comArea = Double.parseDouble(CArea);

		System.out.println("Hit enter to keep Spectator Area at ["+currSpecArea +"] or enter new Spectator Area:");
		String SArea=scan.nextLine();
		double specArea;
		if (SArea.equals(""))
			specArea = currSpecArea;
		else
			specArea = Double.parseDouble(SArea);

		System.out.println("Hit enter to keep Security Number at ["+currSecurity +"] or enter new Security Number:");
		String security=scan.nextLine();
		int securityNum;
		if (security.equals(""))
			securityNum = currSecurity;
		else
			securityNum = Integer.parseInt(security);


		System.out.println("Hit enter to keep base price at ["+currPrice +"] or enter new base price:");
		String Vprice=scan.nextLine();
		double basePrice;
		if (Vprice.equals(""))
			basePrice = currPrice;
		else
			basePrice = Double.parseDouble(Vprice);

		System.out.println("Hit enter to keep level at ["+currlevel +"] or enter new level:");
		String Vlevel=scan.nextLine();
		int level;
		if (Vlevel.equals(""))
			level = currlevel;
		else
			level = Integer.parseInt(Vlevel);

		super.setName(name);
		setCompArea(comArea);
		super.setPrice(basePrice);
		super.setLevel(level);
		setSpecArea(specArea);
		setNumSecurity(securityNum);

	}
        public void updateLocalData(String entered)
        {   
            String[] data = entered.split("/");
            String currName;
            double currArea1;
            double currArea2;
            double currArea3;
            int numSecurity;
            double currPrice; 
            int currLevel;
            
            
            if(data[0].equals("&"))
                    currName= getName();
                else
                    currName = data[0];
                if(data[1].equals("&"))
                    currArea1 = getCompArea();
                else
                    currArea1 = Double.parseDouble(data[1]);
                if(data[2].equals("&"))  
                    currArea2 = getSpecArea();
                else
                    currArea2 = Double.parseDouble(data[2]);
                if(data[3].equals("&"))
                    currArea3 = 0;
                else
                    currArea3 = Double.parseDouble(data[3]);
                
                if(data[4].equals("&"))
                    numSecurity = getNumSecurity();
                else
                    numSecurity = Integer.parseInt(data[4]);
                    
                if(data[5].equals("&"))
                    currPrice = getPrice();
                else
                    currPrice = Double.parseDouble(data[5]);
                if(data[6].equals("&"))
                    currLevel = getLevel();
                else
                    currLevel = Integer.parseInt(data[6]);
                
            setName(currName);
            setCompArea(currArea1);
            setSpecArea(currArea2);
            //setBarArea(area3);
            setNumSecurity(numSecurity);
            setPrice(currPrice);
            setLevel(currLevel);
        }
}
